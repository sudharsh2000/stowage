from django.apps import AppConfig


class TechnoappConfig(AppConfig):
    name = 'technoapp'
